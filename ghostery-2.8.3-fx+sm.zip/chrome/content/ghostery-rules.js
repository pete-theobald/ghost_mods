/**
 * Ghostery Firefox Extension: http://www.ghostery.com/
 *
 * Copyright (C) 2008-2009 David Cancel
 *
 * @author David Cancel
 * @copyright Copyright (C) 2008-2009 David Cancel <dcancel@dcancel.com>
*/
if( !ghostery ) { var ghostery = {}; }	// If Ghostery is not already loaded, define it and set current preferences state.

ghostery.file = {
	
};